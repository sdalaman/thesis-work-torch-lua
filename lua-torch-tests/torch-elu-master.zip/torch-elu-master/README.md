
#    Fast and Accurate Deep Network Learning by Exponential Linear Units (ELUs)
###  Djork-Arné Clevert, Thomas Unterthiner, Sepp Hochreiter
### Torch7 implementation by John-Alexander M. Assael